from flask import Blueprint,render_template,redirect,url_for,session,request,abort,flash, make_response
from models import Livro,lista_livros
import json
rotas_publicas=["Capao.entrada","Capao.index",'Capao.negado']
Capao=Blueprint("Capao",__name__)
@Capao.before_request
def before_request():
    if request.endpoint in rotas_publicas:
        return
    if "username" not in session:
        return redirect(url_for("Capao.negado"))

@Capao.route("/negado")
def negado():
    return render_template("negado.html")
@Capao.route("/")
def entrada():
    return render_template("entrada.html")
@Capao.route("/index", methods=["POST","GET"])
def index():
    if request.method=="GET":
        return render_template("livro.html")
    if request.method=="POST":
        session.permanent=True
        session['lista_livros']=lista_livros
        session["username"]=request.form['username']
        return render_template("index.html")
@Capao.route("/livros")
def Livros():
    cookie=request.cookies.get("Coisas")
    return render_template("livros.html", username=session['username'] ,lista_livros=session['lista_livros'],coisas=cookie)
@Capao.route("/tela-add")
def tela_add():
    return render_template("add.html")
@Capao.route("/add",methods=["POST","GET"])
def Add():
    titulo=request.form['titulo']
    autor=request.form['autor']
    ano=request.form['ano']
    if titulo and autor and ano:
        lista_livros.append(json.dumps({"titulo":titulo,"autor":autor,"ano":ano}))
        response = make_response(redirect(url_for("Capao.Livros")))
        response.set_cookie("Coisas", str(len(lista_livros)), max_age=60*60*24)
        session["lista_livros"]=lista_livros
    elif titulo=="":
        flash("titulo não tem valor", "error")
    elif autor=="":
        flash("autor não tem nada", "error")
    elif ano=="":
        flash("ano não tem nada", "error")
    else:
        flash("Sucesso","sucess")
    return redirect(url_for("Capao.tela_add"))

@Capao.route("/logout")
def logout():
    session.pop("lista_livros",None)
    session.pop("username", None)
    return redirect(url_for("Capao.entrada"))